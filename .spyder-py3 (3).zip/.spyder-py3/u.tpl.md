
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{user}}</title>
    <style>
    body {
      font: 100%/1.1 'Open Sans', Arial, sans-serif;
      margin: 0;
      padding: 20px;
    }
    main {
      padding: 2em 0.5em;
    }
    h1 {
      font-size: 1.5em;
      line-height: 1.5;
      margin: 0 0.5em 0 0;
    }
    p {
      margin: 0 0 2em; 0;
    }
    ul {
      display: flex;
      list-style: none;
      margin: 0;
      padding-left: 0;
    }
    @media screen and (min-width: 60em) {
      li {
        width: 50%;
        padding:5px;
      }
    }
    li span:first-child {
      font-weight: bold;
    }
    span {
      padding:2px;
    }
    button {
      background-color: DeepSkyBlue;
      border: 1px DeepSkyBlue solid;
      border-radius: 4px;
      color: white;
      display: block;
      font-size: inherit;
      padding: 0.5em 2em;
    }
    img {
      width: 100%;
    }

    </style>
    </head>
  
  <body>
    <h1>User Data for /u/{{user}}</h1>
    <p>Comment Data</p>
    <ol> 
    %import praw
    %from textblob import TextBlob 
    %def getcomments(duser):
    %    r = praw.Reddit(client_id="6PrEXHZ4ogjaXA",user_agent="mozil",client_secret="iHG4Tj2rOgWCZt20UZ_j3cNhiDo")
    %    v = r.redditor(duser)
    %    ret = []
    %    for comment in v.comments.new(limit=200):
    %        ret.append(comment)
        % end #ends the forloop
    %    return ret
    % end    #ends the function
    %print('ohai')
    %clist = getcomments(user)
    %for item in clist: #find some way to import lists into templates
        %contentblob = TextBlob(item.body)
        <li>
        <span>{{item}}</span>
        </ br>
        <span>{{item.body}}</span>
        </ br>
        <span>{{contentblob.sentiment}}</span>
        </li>
    % end
    </ol>
    <p>
    last generated at {{timefetched}}
    </p>
  </body>
</html>
