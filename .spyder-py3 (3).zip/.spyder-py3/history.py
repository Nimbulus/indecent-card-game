# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Wed Jan 24 15:23:21 2018)---
import bottle
import textblob
import Thread
import tensorflow

## ---(Thu Jan 25 10:49:14 2018)---
import tensorflow
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
textblob.download_corpora
import textblob
textblob.download_corpora
textblob.download_corpora()
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
import datetime
datetime.now()
datetime.time
datetime.time()
datetime.datetime()
datetime.datetime(1)
datetime.datetime(1,1,1)
datetime.time
datetime.time(20)
datetime.date.today*(
)
datetime.date.today()
print(datetime.date.today())
print(datetime.date.today(1))
print(datetime.date.today())
import time
time.strftime("%c")
from textblob import TextBlob
v = TextBlob("This is a triumph of wit and brevity")
v.sentences
v.noun_phrases
v.sentiment
v.tags
wiki = TextBlob("Python is a high-level, general-purpose programming language.")
wiki.noun_phrases
v.detect_language
v.detect_language()
v.words
v = TextBlob("I hate you niggers!")
v.tags()
v.tags
v.sentiment
v.noun_phrases
v.polarity
v = "I love you boys"
v = TextBlob("I love you boys")
v.sentiment
v.TextBlob("the jews are behind everything")
v = TextBlob("the jews are behind everything")
v.sentiment
v = TextBlob("Stormfront is a white nationalist,[3] white supremacist and neo-Nazi Internet forum, and the Web's first major racial hate site.")
v.sentiment
v = TextBlob("Stormfront is a white nationalist, white supremacist and neo-Nazi Internet forum, and the Web's first major racial hate site.")
v.sentiment
v.sentences
v.noun_phrases
time.strftime("%c")
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
import praw
r = praw.Reddit()
r = praw.Reddit(client_id="none")
r = praw.Reddit(client_id="none",user_agent="mozil")
r = praw.Reddit(client_id="none",user_agent="mozil",client_secret=None)
r.redditor("andy_schlafly)
r.redditor("andy_schlafly")
v - r.redditor("andy_schlafly")
v = r.redditor("andy_schlafly")
v.comments()
v.comments
for comment in v.comments.new():
    print(comment.body)
    
r = praw.Reddit(client_id="6PrEXHZ4ogjaXA",user_agent="mozil",client_secret="iHG4Tj2rOgWCZt20UZ_j3cNhiDo")
v = r.redditor("andy_schlafly")
v.comments
for comment in v.comments.new():
    print(comment.body)
    
for comment in v.get_comments(limit=1000):
    print(comment.body)
    
v = r.get_redditor("andy_schlafly")
for comment in v.comments.new(limit=1000):
    print(comment.body)
    
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
v
v.comments.new
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
def getcomments(luser):
            r = praw.Reddit(client_id="6PrEXHZ4ogjaXA",user_agent="mozil",client_secret="iHG4Tj2rOgWCZt20UZ_j3cNhiDo")
            v = r.redditor(luser)
            ret = []
            for comment in v.comments.new(limit=30):
                ret.append(comment)
            
            return ret

getcomments("andy_schlafly")
import praw
getcomments("andy_schlafly")
r = getcomments("andy_schlafly")
r[0]
r['dtaburp']
r[0]
r[0]['dtaburp']
r[0]{'dtaburp'}
r[0]('dtaburp')
r[0]
praw.Reddit.comment
r[0].body
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
%clear
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
b = [1,2,3]
str(b)
getcomments('andy_schlafly')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
tuple(getcomments('andy_schlafly'))
d = tuple(getcomments('andy_schlafly'))
d[0]
d[0].id
d[0].body
d[0] = bob
d[0] = "bob"
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')

## ---(Tue Feb  6 12:27:13 2018)---
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
v = TextBlob("Hello world! Welcome to the world of Niggers!")
v.sentiment
str(v)
v
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
v = getcomments('spez')
v
v[1]
v[1].content
v[1].body
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
v = getcomments('spez')
mostEmotional(v)
x = mostEmotional(v)
x[1]
x[1].body
x[0].body
v
v[1]
type(v[1])
praw.models.reddit.comment.Comment.upvoted
v[1].body
v[1]
v[1].id
v[1].time
v[1].created
datetime.datetime.fromtimestamp(v[1].created).strftime('%Y-%m-%d %H:%M:%S'))
import datetime
datetime.datetime.fromtimestamp(1517372356.0).strftime('%Y-%m-%d %H:%M:%S')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
0x10000
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')

## ---(Thu Feb  8 14:28:22 2018)---
runfile('C:/Users/US72271/.spyder-py3/temp.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')
a = ['a','bsd','open','theo','de raadt']
a.delete[0]
a.remove('bsd')
a
'a' in a
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')
import random
random.choice('bsd','negroids')
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')

## ---(Wed Feb 14 13:12:28 2018)---
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')
r = "hef"
r.upper()
activeGames = {'dummy':[1,2],}
activeGames['dummy']
activeGames['dummy'][0]
activeGames.update
activeGames.update('bob':[12,3])
activeGames.update({'bob':[12,3]})
activeGames
activeGames.update({'bilbo':{'bob':2}})
activeGames
activeGames('bilbo')
activeGames['bilbo']
activeGames['bilbo']['bob']
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')

## ---(Thu Feb 15 18:16:58 2018)---
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')

## ---(Tue Feb 20 09:51:13 2018)---
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')
for x in range(2)
for x in range(2):
    print(x)
    
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')

## ---(Mon Feb 26 15:10:54 2018)---
runfile('C:/Users/US72271/.spyder-py3/ajax test.py', wdir='C:/Users/US72271/.spyder-py3')
"this".upper()

## ---(Tue Feb 27 14:17:39 2018)---
b = {'bob':stuff}
b = {'bob':stuff'}
b = {'bob':'stuff'}
b.get('bob')
b
b()
b
b.get()
b.text
b.items
b.items()
b.keys('bob')
b.keys()
b.setdefault('bob')
b.setdefault('bob','niger')
len(b)
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')
b = {'bilbo':12,'dx':3}
b.values
b.values()
b.setdefault('bilbo':4)
b.setdefault('bilbo',4)
b.update('bilbo',4)
b.update('bilbo')
b.update({'bilbo':4})
b
b.update({'XKCD':{'players':{'randon':0,'alex':1},'numberOfPlayers':4}})
b
a = {'randalf':2}
tempDict = {**a, **b.get('XKCD').setdefault('players',{,})}
tempDict = {**a, **b.get('XKCD').setdefault('players',{})}
tempDict
b.get('XKCD').get('players').update(tempdict)
b.get('XKCD').get('players').update(tempDict)
b
len(b.get(pageName).get(players))
len(b.get('XKCD').get('players'))
b
b.keys()
b.keys()[0]
b.keys()[1]
b.keys().get(0)
b.keys(1)
str(b.keys())
r = b.keys()
r[1]
b.items()
list(b.items())
b
str(b)

## ---(Thu Mar 22 10:56:02 2018)---
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
alphabet
alphabet[23]
alphabet[24]
alphabet[25]
alphabet[26]
alphabet[-1]
alphabet[-2]
alphabet[-25
]
alphabet[-26]
alphabet[-27]
alphabet.index('a')
alphabet.index('eds')
lower("AGAR")
"AGAR".lower()
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
vignere("soylentgreenispeople","bobenvagene")
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
vignere("soylentgreenispeople","bobenvagene")
key = "bobsenvegene"
key[1]
1%5
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
vignere("soylentgreenispeople","bobenvagene")
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
vignere("soylentgreenispeople","bobenvagene")
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
vignere("soylentgreenispeople","bobenvagene")
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
vignere("soylentgreenispeople","bobenvagene")
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
vignere('a','a')
vignere('a','b')
vignere('b','b')
vignere('z','z')
vignere('s','t')
vignere('t','s')
vignere("thepackagehasbeendelivered","snitchsnitchsnitchsnitchsn")
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
vignere("thepackagehasbeendelivered","snitchsnitchsnitchsnitchsn")
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
vignere("thepackagehasbeendelivered","snitchsnitchsnitchsnitchsn")
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
vignere("thepackagehasbeendelivered","snitchsnitchsnitchsnitchsn")
vignere('lumicjcnoxjhkomxpkwyqogywq','snitchsnitchsnitchsnitchsn')
vignere("snitchsnitchsnitchsnitchsn",'lumicjcnoxjhkomxpkwyqogywq')
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
decipher("snitchsnitchsnitchsnitchsn","lumicjcnoxjhkomxpkwyqogywq")
runfile('C:/Users/US72271/vignere challenge.py', wdir='C:/Users/US72271')
decipher("snitchsnitchsnitchsnitchsn","lumicjcnoxjhkomxpkwyqogywq")
decipher('c','b')
decipher('e','d')
decipher("lumicjcnoxjhkomxpkwyqogywq","snitchsnitchsnitchsnitchsn")
decipher("lumicjcnoxjhkomxpkwyqogywq","snitch")
vignere("theredfoxtrotsquietlyatmidnight","bond")
vignere("murderontheorientexpress","train")
vignere("themolessnuckintothegardenlastnight","garden")
decipher("klatrgafedvtssdwywcyty","cloak")
decipher("pjphmfamhrcaifxifvvfmzwqtmyswst","python")
decipher("rcfpsgfspiecbcc","moore")
runfile('C:/Users/US72271/.spyder-py3/cards_against_decency.py', wdir='C:/Users/US72271/.spyder-py3')