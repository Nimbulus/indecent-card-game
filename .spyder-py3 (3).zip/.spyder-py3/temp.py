# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
from bottle import route, run, template
from textblob import TextBlob
from threading import Thread
import time
import praw


def getcomments(user,amount=50):
    r = praw.Reddit(client_id="6PrEXHZ4ogjaXA",user_agent="mozil",client_secret="iHG4Tj2rOgWCZt20UZ_j3cNhiDo")
    v = r.redditor(user)
    ret = []
    for comment in v.comments.new(limit=amount):
        ret.append(comment)
    return ret

def mostEmotional(commentlist): #commentlist is a list of praw comments
    subjectivity = 0.0
    retlist = []
    for item in commentlist:
        itemb = TextBlob(str(item.body))
        if itemb.sentiment[1] > subjectivity:
            subjectivity = itemb.sentiment[1] # find the highest sentiment gets
    for item in commentlist:
        itemb = TextBlob(str(item.body))
        if itemb.sentiment[1]==subjectivity:
            retlist.append(item)
    return retlist

@route('/u/<name>/<amount>')
def index(name):
    comments = getcomments(name,int(amount))
    highEmotion = mostEmotional(comments)
    with open('u.txt') as f:
        u = f.read()
    udict = {'user': name, 'timefetched':time.strftime("%c"),'commentslist': comments, 'emotions':highEmotion}
    return template(u, **udict)

run(host='localhost', port=8080)
