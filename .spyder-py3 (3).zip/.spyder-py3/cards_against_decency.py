from bottle import route, run, template, static_file, request, redirect, response
from textblob import TextBlob
from threading import Thread
import time
import os
import random
import string



"""
TODO: on HTML page, check if game state is ready. 


"""



dir_path = os.path.dirname(os.path.realpath(__file__))
activeGames = {'gameID':{'numberOfPlayers':[4], 'playersJoined':1, 'players':{'username':1,"username2":2}}} # a dict of active games, with number of players, that gets popped out when games complete

def randID(size=4, chars=string.ascii_uppercase):
    return ''.join(random.choice(chars) for _ in range(size))

@route('/index.pl')
def index():
    with open('cards_against_start.html') as f:
        u = f.read()
    udict = {'timefetched':time.strftime("%c"),}
    return template(u, **udict)

@route('/index.pl', method='POST')
def game_handle():
    gameAction = request.forms.get('join_make') #name of the form
    gameActionParams = request.forms.get('landingText')
    if gameAction == "joinGame":
        redirect("/"+gameActionParams.upper())
    if gameAction == "makeGame":
        gameID = randID()
        activeGames.update({gameID:{'numberOfPlayers':gameActionParams},}) #gameActionParams will be an int of number of players
        redirect("/"+gameID)

@route('/<pageName>')
def handleLanding(pageName):
    if pageName in activeGames:
        with open('cards_against_game_load.html') as f:
            u = f.read()
            
        udict = {'numPlayers':activeGames[pageName]['numberOfPlayers'],'gameID':pageName}
        return template(u, **udict)
    else:
        redirect("/index.pl")
        
@route('/<pageName>/ajax', method='POST')
def ajaxtest(pageName):
    if pageName in activeGames:
        player = request.forms # {"}
        tempDict = {**player, **activeGames.get(pageName).setdefault('players',{})}
        activeGames.get(pageName).get('players').update(tempDict) #gets a list of players, adds it to the game's playerlist
        if len(activeGames.get(pageName).get('players'))==int(activeGames.get(pageName).get('numberOfPlayers')): #not all the players have joined yet
            
            return "done"
            playerCookie = request.cookies.get('playerCookie', '0')
            if playerCookie == 0:
                response.set_cookie('playerCookie', list(player)[0])
        else:
            #not all the playesr have joined yet
            playerCookie = request.cookies.get('playerCookie', '0')
            if playerCookie == 0:
                response.set_cookie('playerCookie', list(player)[0])
            return "waiting" #+ str(len(activeGames.get(pageName).get('players'))) + " "+ activeGames.get(pageName).get('numberOfPlayers')
        
    else:
        return "error 404"
@route('/<pageName>/ajax', method='GET')
def ajaxtest(pageName):
    if pageName in activeGames:
        return str(activeGames)
    else:
        return "game not found"


@route('/static/css/<filename>')
def server_static(filename):
    return static_file(filename, root=dir_path+'\\static\\css')
@route('/static/js/<filename>')
def server_static(filename):
    return static_file(filename, root=dir_path+'\\static\\js')


run(host='localhost', port=8000)
